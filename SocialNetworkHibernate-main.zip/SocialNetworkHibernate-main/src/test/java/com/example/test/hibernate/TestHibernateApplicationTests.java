package com.example.test.hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
